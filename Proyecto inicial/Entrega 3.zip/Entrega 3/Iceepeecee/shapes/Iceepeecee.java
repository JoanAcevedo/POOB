import java.util.*;

/**
 * Iceepeecee es un simulador basado en el problema F de la maraton
 * de programacion internacional 2022 Islands from the Sky
 *
 * @author Joan Acevedo
 * @version 16/10/2023
 */
public class Iceepeecee
{
    private HashMap<String, Island> islands = new HashMap<String, Island>();
    private HashMap<String, Fligth> fligths = new HashMap<String, Fligth>();
    private boolean isVisible;
    private boolean ok;
    private Rectangle territory;
    private final String[] COLORS ={"red", "black", "blue", "yellow", "green", "magenta", "cyan", "gray", "orange", "pink"};
    
    /**
     * Crea el territorio donde se realizara la simulacion
     * 
     * @param length, largo del territorio
     * @param width, ancho del territorio
     */
    public Iceepeecee(int length, int width){
        this.ok = false;
        if(length > 0 && width > 0){
            this.territory = new Rectangle(length, width);
            territory.changeColor("white");
            this.ok = true;
        }
    }
    
    /**
     * Constructor con la entrada apropiada a la del maraton
     * 
     * @param islands, conjunto de islas a ingresar
     * @param fligths, conjuntos de vuelos a ingresar
     */
    public Iceepeecee(int [][][] islands, int [][][] fligths){
        // cuando miremos excepciones, se debe realizar una 
        // que arroje una excepcion cuando el tamaño de la isla supere el territorio
        this.territory = new Rectangle(500, 500);
        territory.changeColor("white");
        for(int i = 0; i < islands.length; i++){
            String color = anyColor();
            while(this.islands.containsKey(color) && this.islands.size() < this.COLORS.length){
                color = anyColor();
            }
            Island isla = new Island(color, islands[i]);
            this.islands.put(color, isla);
        }
        // cuando miremos excepciones, se debe realizar una 
        // que arroje una excepcion cuando el recorrido del vuelo supere el territorio
        for(int i = 0; i < fligths.length; i++){
            int[] from = fligths[i][0];
            int[] to = fligths[i][1];
            String color = anyColor();
            while(this.fligths.containsKey(color) && this.fligths.size() < this.COLORS.length){
                color = anyColor();
            }
            Fligth vuelo = new Fligth(color, from, to);
            this.fligths.put(vuelo.getColor(), vuelo);
        }
    }
    
    /**
     * Agrega una isla al territorio
     * 
     * @param color, color de la isla
     * @param polygon, puntos con coordenadas de la isla
     */
    public void addIsland(String color, int[][] polygon){
        this.ok = false;
        if(!islands.containsKey(color)){
            Island island = new Island(color, polygon);
            islands.put(color, island);
            if(this.isVisible){
                island.makeVisible();
            }
            this.ok = true;
        }
    }
    
    /**
     * Agrega un vuelo al territorio
     * 
     * @param color, color del vuelo
     * @param from, punto de despegue
     * @param to, punto de llegada
     */
    public void addFligth(String color, int[] from, int[] to){
        this.ok = false;
        if(!fligths.containsKey(color)){
            Fligth fligth = new Fligth(color, from, to);
            fligths.put(color, fligth);
            if(this.isVisible){
                fligth.makeVisible();
            }
            this.ok = true;
        }
    }
    
    /**
     * Un vuelo realiza una fotografia
     * 
     * @param fligth, color del vuelo que va a tomar la foto
     * @param teta, angulo entero con el que se toma la foto
     */
    public void photograph(String fligth, int teta){
        this.ok = false;
        Fligth vuelo = fligths.get(fligth);
        if(vuelo != null){
            if(teta > 0){
                vuelo.makePhotograph(teta);
                Photograph foto = vuelo.getPhoto();
                if(this.isVisible){
                    foto.makeVisible();
                }
                this.ok = true;
            }
        }
    }
    
    /**
     * Todos los vuelos realizan una foto
     * 
     * @param teta, angulo de la foto
     */
    public void photograph(int teta){
        if(teta > 0){
            for(Map.Entry<String, Fligth> entry : fligths.entrySet()){
                Fligth flight = entry.getValue();
                flight.makePhotograph(teta);
            }
        }
    }
    
    /**
     * Todos los vuelos realizan una foto
     * 
     * @param teta, angulo de la foto
     */
    public void photograph(float teta){
        if(teta > 0){
            for(Map.Entry<String, Fligth> entry : fligths.entrySet()){
                Fligth flight = entry.getValue();
                flight.makePhotograph(teta);
            }
        }
    }
    
    /**
     * Elimina una isla del territorio
     * 
     * @param color, color que identifica a la isla
     */
    public void delIsland(String color){
        this.ok = false;
        Island isla = islands.get(color);
        if(isla != null){
            isla.makeInvisible();
            islands.remove(color);
            this.ok = true;
        }
    }
    
    /**
     * Elimina un vuelo del territorio
     * 
     * @param color, color que identifica el vuelo
     */
    public void delFligth(String color){
        this.ok = false;
        Fligth vuelo = fligths.get(color);
        if(vuelo != null){
            vuelo.makeInvisible();
            fligths.remove(color);
            this.ok = true;
        }
    }
    
    /**
     * Devuelve la locacion de una isla determinada
     * 
     * @param island, color que identifica a la isla
     * @return la locacion de la isla
     */
    public int[][] islandLocation(String island){
        this.ok = false;
        Island isla = islands.get(island);
        this.ok = true;
        return isla != null ? isla.getLocation() : null; // aca esta el condicional que asegura isla != null
    }
    
    /**
     * Devuelve la locacion de una isla determinada
     * 
     * @param island, color que identifica a la isla
     * @return la locacion de la isla
     */
    public int[][] fligthLocation(String fligth){
        this.ok = false;
        Fligth vuelo = fligths.get(fligth);
        this.ok = true;
        return vuelo != null ? vuelo.getLocation() : null; // aca esta el condicional que asegura vuelo != null
        
    }
    
    /**
     * Devuelve el angulo de una foto en especifico
     * 
     * @param color, color de la foto
     * @return entero con el angulo de la foto
     */
    public float fligthCamera(String color){
        this.ok = false;
        Fligth vuelo = fligths.get(color);
        this.ok = true;
        return vuelo != null ? vuelo.anglePhotograph() : null; // aca esta el condicional que asegura vuelo != null
    }
    
    /**
     * Devuelve un arreglo con los identificadores de las islas (color)
     * 
     * @return String[] con las islas (color)
     */
    public String[] islands(){
        Set<String> set = this.islands.keySet();
        String[] conjutoIslas = set.toArray(new String[set.size()]);
        return conjutoIslas;
    }
    
    /**
     * Devuelve un arreglo con los identificadores de las islas (color)
     * 
     * @return String[] con las islas (color)
     */
    public String[] fligths(){
        Set<String> set = this.fligths.keySet();
        String[] conjutoVuelos = set.toArray(new String[set.size()]);
        return conjutoVuelos;
    }
    
    /**
     * Nos indica cuales islas estan siendo observadas por una fotografia
     * 
     * @String[] con los nombres de las islas observadas
     */
    public String[] observedIslands(){
        String[] islas = islands();
        Set<String> islasVistas = new HashSet<>();
        boolean inside = false;
        for(Fligth fligth : fligths.values()){
            for(int i = 0; i < islas.length ; i++){
                inside = fligth.comparacion(this.islands.get(islas[i]).getForm());
                if(inside){
                    islasVistas.add(this.islands.get(islas[i]).getColor());
                }
            }
        }
        String[] islasObservadas = islasVistas.toArray(new String[islasVistas.size()]);
        return islasObservadas;
    }
    
    /**
     * Nos indica cuando un vuelo es inutil, es decir cuando no
     * captura una isla por completo
     * 
     * @String[] con los nombres de los vuelos inutiles
     */
    public String[] uselessFlights(){
        String[] islas = islands();
        Set<String> vuelosInutiles = new HashSet<>();
        boolean inside = false;
        for(Fligth fligth : fligths.values()){
            for(int i = 0; i < islas.length ; i++){
                if(!inside){
                    // Si inside es False, entonces la foto no ha captado la isla [i] 
                    inside = fligth.comparacion(this.islands.get(islas[i]).getForm()); 
                }
            }
            if(!inside){
                // Si inside es True entonces capto por lo menos una isla completa
                vuelosInutiles.add(fligth.getColor());
            }
        }
        String[] vuelosTontos = vuelosInutiles.toArray(new String[vuelosInutiles.size()]);
        return vuelosTontos;
    }
    
    /**
     * Hace visible todo lo que se encuentre dentro del territorio
     */
    public void makeVisible(){
        this.ok = false;
        this.territory.makeVisible();
        for(Island island : islands.values()){
            island.makeVisible();
        }
        for(Fligth fligth : fligths.values()){
            fligth.makeVisible();
        }
        this.isVisible = true;
        this.ok = true;
    }
    
    /**
     * Hace invisible todo lo que se encuentre dentro del territorio
     */
    public void makeInvisible(){
        this.ok = false;
        this.territory.makeInvisible();
        for(Island island : islands.values()){
            island.makeInvisible();
        }
        for(Fligth fligth : fligths.values()){
            fligth.makeInvisible();
        }
        this.isVisible = false;
        this.ok = true;
    }
    
    /**
     * Indica si la ultima accion se pudo realizar
     * <ol>
     * <li> True en caso de que se haya podido realizar la accion
     * <li> False en caso de que no se haya podido realizar la accion
     * </ol>
     */
    public boolean ok(){
        return this.ok;
    }

    /**
     * Finaliza la simulacion
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * Resuelve el problema de maraton encontrando el angulo perfecto
     * 
     * @return float con el angulo correspondiente
     */
    public float resolve(){
        float result = 0;
        String[] islas = islands();
        this.photograph(179);
        String[] islas2 = observedIslands(); 
        if(islas.length != islas2.length){
            result = -1;
        }else{
            this.photograph(90);
            islas2 = observedIslands();
            if(islas.length != islas2.length){
                float r = this.divisionSup(); // valor minimo 91
                float r2 = this.divisionFin(r);
                result = this.divisionFinDec(r2);
            }else{
                float r = this.divisionInf(); // valor minimo 1
                float r2 = this.divisionFin(r);
                result = this.divisionFinDec(r2);
            }
        }
        return result;
    }
    
    /**
     * Pinta las islas que son visibles ante un vuelo con una marca que las identifica
     */
    public void pintarIsla(){
        String[] islasVisibles = observedIslands();
        if(this.isVisible && this.fligths.size() != 0){
            for(int i = 0; i < islasVisibles.length; i++){
                islands.get(islasVisibles[i]).estaFotografiada();
            }
        }
    }
    
    /**
     * Realiza las fotografias de los vuelos invisibles
     */
    public void hacerFotosInvisibles(){
        for(Fligth f : this.fligths.values()){
            f.getPhoto().makeInvisible();
        }
    }

    /*
     * Genera un color aleatorio
     * 
     * @return String con el nombre del color generado
     */
    private String anyColor(){
        int numero = (int)(Math.random()*this.COLORS.length);
        String color = COLORS[numero];
        return color;
    }
    
    /*
     * Realiza una division en intervalos de 10 desde 179 hasta 91
     * Esto nos ayudara a encontrar el angulo perfecto para el metodo "resolve"
     * 
     * @return float con una aproximación del angulo perfecto
     */
    private float divisionSup(){
        String[] islas = islands();
        String[] islas2 = observedIslands();
        float valor = 179;
        int[] valores = {170,160,150,140,130,120,110,100,91};
        for(int i = 0; i < valores.length; i++){
            this.photograph(valores[i]);
            if(islas.length == islas2.length){
                valor = valores[i];
            }else{
                break;
            }
        }
        return valor;
    }
    
    /*
     * Realiza una division en intervalos de 10 desde 90 hasta 1
     * Esto nos ayudara a encontrar el angulo perfecto para el metodo "resolve"
     * 
     * @return float con una aproximación del angulo perfecto
     */
    private float divisionInf(){
        String[] islas = islands();
        String[] islas2 = observedIslands();
        float valor = 90;
        int[] valores = {80,70,60,50,40,30,20,10,1};
        for(int i = 0; i < valores.length; i++){
            this.photograph(valores[i]);
            islas2 = observedIslands();
            if(islas.length == islas2.length){
                valor = valores[i];
            }else{
                break;
            }
        }
        return valor;
    }
    
    /*
     * Realiza una division en intervalos de 1 
     * Esto nos ayudara a encontrar el angulo perfecto para el metodo "resolve"
     * 
     * @return float con una aproximación del angulo perfecto
     */
    private float divisionFin(float num){
        String[] islas = islands();
        String[] islas2 = observedIslands();
        float valor = num;
        float[] valores = {num-1, num-2, num-3, num-4, num-5, num-6, num-7, num-8, num-9};
        for(int i = 0; i < valores.length; i++){
            this.photograph(valores[i]);
            islas2 = observedIslands();
            if(islas.length == islas2.length){
                valor = valores[i];
            }else{
                break;
            }
        }
        return valor;
    }
    
    /*
     * Realiza una division en intervalos de 0.1 
     * Esto nos ayudara a encontrar el angulo perfecto para el metodo "resolve"
     * 
     * @return float con el angulo perfecto
     */
    private float divisionFinDec(float num){
        String[] islas = islands();
        String[] islas2 = observedIslands();
        float valor = num;
        float[] valores = {num -0.1f, num -0.2f, num -0.3f, num -0.4f, num -0.5f, num -0.6f, num -0.7f, num -0.8f, num -0.9f};
        for(int i = 0; i < valores.length; i++){
            this.photograph(valores[i]);
            islas2 = observedIslands();
            if(islas.length == islas2.length){
                valor = valores[i];
            }else{
                break;
            }
        }
        return valor;
    }
}
