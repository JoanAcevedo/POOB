import java.util.Timer;
import java.util.TimerTask;

/**
 * Write a description of class IceepeeceeContest here.
 * 
 * @author Joan Acevedo 
 * @version 16/10/2023
 */
public class IceepeeceeContest
{
    private float angle;
    private int[][][] islands;
    private int[][][] fligths;
    
    /**
     * Constructor for objects of class IceepeeceeContest
     */
    public IceepeeceeContest(){

    }
    
    /**
     * @return float con el angulo apropiado. Si el angulo es "-1", significa que es imposible
     */
    public float solve(int[][][] islands, int[][][] fligths){
        float result = 0;
        Iceepeecee prueba = new Iceepeecee(islands, fligths);
        this.islands = islands;
        this.fligths = fligths;
        result = prueba.resolve();
        this.angle = result;
        return result;
    }
    
    public void simulate(){
        Timer timer = new Timer();
        Iceepeecee prueba = new Iceepeecee(this.islands, this.fligths);
        prueba.makeVisible();
        TimerTask task1 = new TimerTask() {
            @Override
            public void run() {
                prueba.photograph(angle);
                prueba.makeVisible();
            }
        };
        timer.schedule(task1, 3000);
        
        TimerTask task2 = new TimerTask() {
            @Override
            public void run() {
                prueba.hacerFotosInvisibles();
                prueba.pintarIsla();
            }
        };
        timer.schedule(task2, 6000);
    }
}
