import java.awt.Polygon;

/**
 * Vuelo que se realiza sobre Iceepeecee
 *
 * @author Joan Acevedo
 * @version 09/09/2023
 */
public class Fligth
{
    private String color;
    private Line trace;
    private Photograph photo;
    private int[] from;
    private int[] to;
    private int[][] location;
    private boolean isVisible;
    
    /**
     * Constructor del vuelo
     * 
     * @param color, color del vuelo
     * @param from, punto de inicio del vuelo
     * @param to, punto de llegada del vuelo
     */
    public Fligth(String color, int[] from, int[] to){
        this.color = color;
        this.from = from;
        this.to = to;
        trace = new Line(color, from, to);
    }
    
    /**
     * Nos da la distancia de la trayectoria del avion
     * 
     * @return entero con la distancia total
     */
    public int trayectoria(){
        return this.trace.distanciaTotal();
    }
    
    /**
     * Devuelve la locacion del vuelo
     * 
     * @return una matriz con la locacion del vuelo
     */
    public int[][] getLocation(){
        location[0] = this.from;
        location[1] = this.to;
        return this.location;
    }
    
    /**
     * Devuelve el color del vuelo
     * 
     * @return String con el color del vuelo
     */
    public String getColor(){
        return this.color;
    }
    
    /**
     * Devuelve la fotografia
     * 
     * @return fotografia del vuelo
     */
    public Photograph getPhoto(){
        return this.photo;
    }
    
    /**
     * Crea una fotografia
     * 
     * @param int, angulo de la foto
     */
    public void makePhotograph(float teta){
        this.photo = new Photograph(this.color, teta, this.from, this.to);
        if(this.isVisible){
            this.photo.makeVisible();
        }
    }
    
    /**
     * Devuelve el angulo de la fotografia
     * 
     * @return entero con el angulo de la fotografia
     */
    public float anglePhotograph(){
        return this.photo.getTeta();
    }
    
    /**
     * Nos indica si el poligono de la isla esta dentro del poligono de la foto
     * 
     * @boolean True si esta adentro, False si no lo esta
     */
    public boolean comparacion(Polygon formaIsla){
        return this.photo.comparacion(formaIsla);
    }
    
     /**
     * Hace visible la isla
     */
    public void makeVisible(){
        isVisible = true;
        trace.makeVisible();
        if(this.photo != null){
            photo.makeVisible();    
        }
        
    }
    
    /**
     * Hace invisible la isla
     */
    public void makeInvisible(){
        trace.makeInvisible();
        isVisible = false;
    }  

}
