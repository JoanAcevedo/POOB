package iceepeecee;

import excepciones.IceepeeceeException;

/**
 * Write a description of class NormalIsland here.
 * 
 * @author Joan Acevedo 
 * @version 04/11/2023
 */
public class NormalIsland extends Island
{
    public NormalIsland(String color, int[][] polygon, int lengthT, int widthT) throws IceepeeceeException {
        super(color,polygon,lengthT,widthT);
    }
}
